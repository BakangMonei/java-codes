package package1;

/*
author: Monei Bakang
title: Java program to convert Decimal to [Binary, Hexadecimal & Octal] numbers
*/

public class Decimal_Conversion{
public static void main(String[] args){
    Convert obj = new Convert();
    obj.getVal();
    obj.convert();
}
}